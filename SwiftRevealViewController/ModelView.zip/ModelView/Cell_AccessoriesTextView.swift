//
//  Cell_AccessoriesTextView.swift
//  SwiftRevealViewController
//
//  Created by Devang Patel on 12/01/18.
//  Copyright © 2018 kkontus. All rights reserved.
//

import UIKit

class Cell_AccessoriesTextView: UITableViewCell {
    @IBOutlet weak var txtDescri : UITextView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
